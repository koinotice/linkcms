import { DataQuery, DataSourceJsonData } from '@grafana/data';

export interface GenericQuery extends DataQuery {}

export interface GenericOptions extends DataSourceJsonData {}
