export default function(){
    return '#$__panelId{\r\n\t/*Your css style here*/\r\n}';
}