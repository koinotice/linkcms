export default function(){
    return '<div id="$__panelId" class="echart-panel__chart"></div>';
}