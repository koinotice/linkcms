import './polyfills.js';
import _ from 'lodash';
import { HTMLCtrl } from './html_ctrl';

export {
    HTMLCtrl as PanelCtrl
};
